export interface AjoutLoginAdmin {
    name : string,
    last_name : string,
    mail : string,
    password : string
}
