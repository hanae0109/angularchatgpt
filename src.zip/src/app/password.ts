export interface Password {
    password : string
}
