export interface UserInfoLogin {

    id : number,
    name : string,
    last_name : string,
    mail : string,
    change : boolean,
    otpactive : boolean
}
