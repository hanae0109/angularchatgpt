import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';

import { AdminInfoLogin } from './admin-info-login';
import { AdminLogin } from './admin-login';
import { AjoutLoginAdmin } from './ajout-login-admin';
import { AjoutLoginUser } from './ajout-login-user';
import { Otp } from './otp';
import { Password } from './password';
import { Url } from './url';
import { UserInfoLogin } from './user-info-login';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  public infoAdmin! : AdminInfoLogin


  constructor(private http: HttpClient) { }

  public signIn(admin: AdminLogin): Observable<AdminInfoLogin> {
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(admin);
    const url = 'http://10.10.40.5:30000/authentication/login/admin';
    return this.http.post<AdminInfoLogin>(url, body ,{'headers':headers})
    
  }

  public sendOtp(otp : Otp) : Observable<AdminInfoLogin> {
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(otp);
    const url = 'http://10.10.40.5:30000/authentication/login/admin/otp';
    return this.http.post<AdminInfoLogin>(url, body ,{'headers':headers})
  }

  public createOtp(id : number) : Observable<Url> {
    const url = `http://10.10.40.5:30000/admin-management/admins/${id}/otp`;
    return this.http.post<Url>(url, null)
  }

  public changePassword(password : Password, id : number) : Observable<AdminInfoLogin>{
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(password);
    console.log("Le body password : "  + body);
    const url = `http://10.10.40.5:30000/admin-management/admins/${id}`;
    return this.http.patch<AdminInfoLogin>(url, body ,{'headers':headers})
  }

  public ajoutUser(user : AjoutLoginUser) : Observable<UserInfoLogin>{
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(user);
    console.log("Le user: "  + body);
    const url = `http://10.10.40.5:30000/user-management/users`;
    return this.http.post<UserInfoLogin>(url, body ,{'headers':headers})
  }

  public ajoutAdmin(admin : AjoutLoginAdmin) : Observable<AdminInfoLogin>{
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(admin);
    console.log("L'admin: "  + body);
    const url = `http://10.10.40.5:30000/admin-management/admins`;
    return this.http.post<AdminInfoLogin>(url, body ,{'headers':headers})
  }


  public getListAdmin() : Observable<AdminInfoLogin[]>{
    const url = `http://10.10.40.5:30000/admin-management/admins`;
    return this.http.get<AdminInfoLogin[]>(url)
  }

  public getListUser() : Observable<UserInfoLogin[]>{
    const url = `http://10.10.40.5:30000/user-management/users`;
    return this.http.get<UserInfoLogin[]>(url)
  }

  public deleteUser(id : number) : Observable<number>{
    const url = `http://10.10.40.5:30000/user-management/users/${id}`;
    return this.http.delete<number>(url)
  }

  public deleteAdmin(id : number) : Observable<number>{
    const url = `http://10.10.40.5:30000/admin-management/admins/${id}`;
    return this.http.delete<number>(url)
  }

  public setInfoAdmin(admin : AdminInfoLogin){
    this.infoAdmin = admin
  }
  
  public getInfoAdmin() : AdminInfoLogin{
    return this.infoAdmin
  }
}
