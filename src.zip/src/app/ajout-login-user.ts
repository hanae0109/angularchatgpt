export interface AjoutLoginUser {
    name : string,
    last_name : string,
    mail : string,
    password : string
}
