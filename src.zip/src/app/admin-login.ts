export interface AdminLogin {
    mail : string
    password : string
}
