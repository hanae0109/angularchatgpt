import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminInfoLogin } from 'src/app/admin-info-login';
import { AuthenticationService } from 'src/app/authentication.service';
import { Otp } from 'src/app/otp';

@Component({
  selector: 'app-enterotp',
  templateUrl: './enterotp.component.html',
  styleUrls: ['./enterotp.component.scss']
})
export class EnterotpComponent {
  public isBold: boolean;
  public otp: string ='';
  public error: string ='';
  public credential! : Otp
  public infoLogin! : AdminInfoLogin
  public otpForm: FormGroup;
  public otpCrtl: FormControl;


  constructor(protected router: Router, protected authenticationService : AuthenticationService) {
    this.isBold = false
    this.otpCrtl = new FormControl('')
    this.otpForm = new FormGroup({
        otp: this.otpCrtl,
    })
   }

  ngOnInit(): void {
    this.otpCrtl = new FormControl('')
    this.otpForm = new FormGroup({
        otp: this.otpCrtl,
    })
   }
  
   onFocusOut() {
    this.isBold = false;
  }
  
  enterOtp() {
    this.error = '';
    this.otp = this.otpCrtl.value.trim();
    if (this.otp.length !=6 ) {
      this.error = "Code invalide";
    }
    else{
      this.credential = { code : this.otp}
      console.log("Appuie sur le bouton envoie otp: " + this.credential)
      this.authenticationService.sendOtp(this.credential).subscribe({
        next: (data : AdminInfoLogin) => {
          this.infoLogin = data
          console.log("Voici les donnees de l admin : " + this.infoLogin)
          if (this.infoLogin.change == true ){
            this.router.navigate(['/menu']);
          }
          else{
            this.router.navigate(['/profil']);
          }
        },
        error: (e) => {
          console.error(e)
          this.error = "Code invalide"
        },
      })
    }
  }
}