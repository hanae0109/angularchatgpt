import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { LogoComponent } from './logo/logo.component';
import { FormComponent } from './form/form.component';
import { EnterotpComponent } from './enterotp/enterotp.component';
import { CreateotpComponent } from './createotp/createotp.component';



@NgModule({
  declarations: [
    LoginComponent,
    LogoComponent,
    FormComponent,
    EnterotpComponent,
    CreateotpComponent
  ],
  imports: [
    CommonModule,
    LoginRoutingModule,
    FormsModule
  ]
})
export class LoginModule { }
