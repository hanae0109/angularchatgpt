import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminInfoLogin } from 'src/app/admin-info-login';
import { AdminLogin } from 'src/app/admin-login';
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  public mail: string;
  public password: string;
  public error: string;
  public success: string;
  public credential! : AdminLogin;
  public infoLogin! : AdminInfoLogin;
  public isBold: boolean;
  
    constructor(protected router: Router, protected authenticationService : AuthenticationService) {
      this.mail = '';
      this.password = '';
      this.error = '';
      this.success = '';
      this.isBold = false;
    }

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
     
  onFocusOut() {
    this.isBold = false;
  }

  firstAuthent() {
    this.error = '';
    if (this.mail == '' || this.password == '') {
      this.error = "L'indentifiant et le mot de passe de doivent pas être vides";
    }
    else{
      this.credential = { mail : this.mail, password : this.password}
      console.log("Appuie sur le bouton : " + this.credential)
      this.authenticationService.signIn(this.credential).subscribe({
        next: (data : AdminInfoLogin) => {
          this.infoLogin = data
          console.log("Voici les donnees de l'admin : " + this.infoLogin)
          this.authenticationService.setInfoAdmin(this.infoLogin)
          if(this.infoLogin.otpactive == false){
            this.router.navigate(['/createotp']);
          }
          else  {
            this.router.navigate(['/enterotp']);
          }
        },
        error: (e) => {
          console.error(e)
          this.error = "Le mail et/ou le mot de passe sont incorrects"
        },
      })
    }
  }
}