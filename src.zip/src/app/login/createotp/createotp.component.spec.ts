import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateotpComponent } from './createotp.component';

describe('CreateotpComponent', () => {
  let component: CreateotpComponent;
  let fixture: ComponentFixture<CreateotpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateotpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateotpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
