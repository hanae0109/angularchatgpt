import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminInfoLogin } from 'src/app/admin-info-login';
import { AuthenticationService } from 'src/app/authentication.service';
import { Url } from 'src/app/url';

@Component({
  selector: 'app-createotp',
  templateUrl: './createotp.component.html',
  styleUrls: ['./createotp.component.scss']
})
export class CreateotpComponent {
  public isBold : boolean
  public infoAdmin! : AdminInfoLogin
  public code : string =''
  public error : string = ''

  constructor(protected router: Router, protected authenticationService : AuthenticationService) {
    this.isBold = false
  }

  ngOnInit(): void {
    this.infoAdmin = this.authenticationService.getInfoAdmin()
  }

  onFocusOut() {
    this.isBold = false;
  }

  createOtp(){
    this.authenticationService.createOtp(this.infoAdmin.id).subscribe({
      next: (data : Url) => {
        this.code = data.url
        console.log("Voici les donnees de l admin : " + this.code)
        this.infoAdmin.otpactive = true;
        this.authenticationService.setInfoAdmin(this.infoAdmin)        
      },
      error: (e) => {
        console.error(e)
        this.error = "Vous avez deja la double authentification activée"
      },
    })
  }

  nextPage(){
      this.router.navigate(['/enterotp']); // on va venir finir sa connexion
    }
}
