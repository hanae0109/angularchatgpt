export interface Url {
    url : string
}
