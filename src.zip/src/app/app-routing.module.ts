import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { BastionlistComponent } from './bastionlist/bastionlist.component';
import { FormComponent } from './login/form/form.component';
import { EnterotpComponent } from './login/enterotp/enterotp.component';
import { CreateotpComponent } from './login/createotp/createotp.component';
import { LogoComponent } from './login/logo/logo.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent, children: [
    { path: 'form', component: FormComponent},
    { path: 'logo', component: LogoComponent},
    { path: 'enterotp', component: EnterotpComponent},
    { path: 'createotp', component: CreateotpComponent},
  ]}, 
  { path: 'bastionlist', component: BastionlistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
