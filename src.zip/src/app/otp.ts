export interface Otp {
    code : string
}
