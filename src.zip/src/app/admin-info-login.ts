export interface AdminInfoLogin {
    id : number
    name : string
    last_name : string
    mail : string
    change : boolean
    otpactive : boolean
}
