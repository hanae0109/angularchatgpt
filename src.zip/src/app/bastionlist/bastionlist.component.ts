import { Component } from '@angular/core';
@Component({
  selector: 'app-bastionlist',
  templateUrl: './bastionlist.component.html',
  styleUrls: ['./bastionlist.component.scss']
})
export class BastionlistComponent {
  isMenuCollapsed = true;
  public error: string;
  public success: string;
  rows = [
    {
      name: 'BASTION 1',
      connected: '6',
    },
    {
      name: 'BASTION 2',
      connected: '10',
    },
    {
      name: 'BASTION 3',
      connected: '7',
    }
  ];
  columns = [
    { prop: 'name', name: 'Nom du Bastion' },
    { prop: 'connected', name: 'Nombre de personnes connectées au bastion' },
  ];
  closeResult!: string;
  bastionData: any={bastion_net_id: null, name: null, agent_endpoint: null, cidr_protege: null};

  constructor() {
    this.error = '';
    this.success = '';
  }
}
